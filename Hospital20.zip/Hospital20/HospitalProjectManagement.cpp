#include <iostream> 
#include"DoctorSalaryProcess.h"
#include"BaseClass.h"
using namespace std;


int main()
 {
	DoctorSalaryProcess oBasic;
	   int choice;
	   char x;

	while(1)
	{
		cout << "\n\nEnter your choice : ";
		cin >> choice;
		switch (choice)
		{

		case 1:
			do {

				oBasic.GetBasicDetais();
				cout << "\n\nWant to add Employee Basic Details (y/n) : ";
				cin >> x;
			} while (x == 'y');
			break;

		case 2:
			do {

				oBasic.ProcessData();
				cout << "\n\nWant to Add Employee Atendance Details (y/n) : ";
				cin >> x;
			} while (x == 'y');
			 break;
		case 3:
		{

			oBasic.OutputData();
			//oBasic.GetLine();
			break;
		}
		case 4:
		{
			oBasic.GetLine();
			break;
		}
		default :
			cout << "\n\nINVALID CHOICE\n";
			
		}
	}
 return 0;
}

