#pragma once
class Baseclass
{
public:
	void GetBasicDetais();
	void ProcessData();
	void OutputData();
	void GetLine();
};
