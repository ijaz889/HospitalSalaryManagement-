#pragma once


#pragma once
#include"BaseClass.h"
#include<iostream>
class DoctorSalaryProcess : public Baseclass
	{

	public:
		void GetBasicDetais();
		void ProcessData();
		void OutputData();
		void GetLine();
	private:
		std::string m_sName = "";
		std::string m_sRole = "";
		std::string m_sId = "";
		int m_nBasicPay = 0;
		int m_nNoOfDaysAttended = 0;
		int m_nNoOfPatientAttented = 0;
		int m_nNoOfLabProcedures = 0;
		int m_nSalaryCalculation = 0;
		int m_nNumberOfRecords = 0;
	};



