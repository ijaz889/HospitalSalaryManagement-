#include "DoctorSalaryProcess.h"

#include <fstream> 
#include <iostream> 
#include <stdio.h> 
#include <stdlib.h> 
#include<string>

using namespace std;

void DoctorSalaryProcess::GetBasicDetais()
{

	system("cls");
	fstream file;


	cout << "\n\n\t\t\t\tADD Employee";
	cout << "\n\nEmployee Name : ";
	cin >> m_sName;
	cout << "\nEmployee Role : ";
	cin >> m_sRole;
	cout << "\nEmployee Id : ";
	cin >> m_sId;
	cout << "\nBasic Pay : ";
	cin >> m_nBasicPay;
	file.open(" book12.txt",
		ios::out | ios::app);
	file << " " << m_sName << " "
		<< m_sRole << " " << m_sId
		<< " " << m_nBasicPay << "\n";
	file.close();
	file.open(" book.txt",
		ios::out | ios::app);
	file << " " << m_sName << " "
		<< m_sRole << " " << m_sId
		<< " " << m_nBasicPay << "\n";

	file.close();

}

void DoctorSalaryProcess::ProcessData()
{
	system("cls");

	fstream file;

	
	cout << "\nEmployee Id : ";
	cin >> m_sId;
	cout << "\n\n\t\t\t\tADD Employee Attendence";
	cout << "\n\nNoOfDaysAttended : ";
	cin >> m_nNoOfDaysAttended;
	cout << "\nNoOfPatientAttented : ";
	cin >> m_nNoOfPatientAttented;
	cout << "\nNoOfLabProcedures : ";
	cin >> m_nNoOfLabProcedures;
	cout << "\nBasic Pay : ";
	cin >> m_nBasicPay;
	m_nSalaryCalculation = m_nBasicPay + (m_nNoOfDaysAttended * 500) + (m_nNoOfPatientAttented * 200) + (m_nNoOfLabProcedures * 100);
	cout << "\nEmployee Total Salary : "<< m_nSalaryCalculation;
	

	//file.open(" book23.txt", ios::out | ios::app);
	file.open(" book1.txt", ios::out | ios::app);
	file << " " << m_sId << " " << m_nNoOfDaysAttended << " "
		<< m_nNoOfPatientAttented << " " << m_nNoOfLabProcedures
		<< " " << m_nBasicPay << " " << m_nSalaryCalculation << "\n";
	file.close();




}

void DoctorSalaryProcess::OutputData()
{
	system("cls");
	fstream file;

	cout << "\n\n\t\t\t\t\tAll Employee Details";

	// Open the file in input mode 
	file.open(" book.txt", ios::in);
	if (!file)
		cout << "\n\nFile Opening Error!";
	else {

		cout << "\n\n\nEmployee ID\t\tRole"
			<< "\t\tEmployee Name\t\tBasic Pay \t\tEmployee Total Salary \n";
		file >> m_sId >> m_sRole;
		file >> m_sName >> m_nBasicPay;

		// Till end of file is reached 
		while (!file.eof()) {

			cout << " " << m_sId
				<< "\t\t" << m_sRole
				<< "\t\t" << m_sName
				<< "\t\t" << m_nBasicPay
				<< "\n\n";
			file >> m_sId >> m_sRole;
			file >> m_sName >> m_nBasicPay;
		}

		system("pause");

		// Close the file 
		file.close();
	}

}

void DoctorSalaryProcess::GetLine()
{
	DoctorSalaryProcess os;
	fstream fp2;
	fp2.open("book.txt", ios::in);
	int size = sizeof(os);
	int number = 0;
	while (1)
	{
		fp2.read((char*)&os,sizeof(os));
		if (fp2.eof())
			break;
		number++;
	}
	fp2.close();
	cout << endl << "Number of Records" << number;

}
